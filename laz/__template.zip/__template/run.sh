#!/bin/bash


echo -n "new application id (alpha-only!) # "
read ID

D=../$ID

if [[ ! -d $D ]]; then
    cp -a src $D
    echo "export ID=$ID" >$D/.id
    ( cd $D/src && bash all.sh )
    ( cd $D && make cb )
fi
