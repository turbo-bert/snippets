#!/bin/bash



LA=$(gfind build -type d -iname "*.app" | sort | tail -1)

if [[ ! -z "$LA" ]]; then
    echo "$LA"
    open "$LA"
fi

