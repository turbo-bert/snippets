#!/bin/bash


source .id

open -a "$HOME/Applications/lazarus/startlazarus.app" --args "$PWD/src/$ID.lpi"
