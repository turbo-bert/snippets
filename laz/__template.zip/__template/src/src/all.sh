#!/bin/bash


source ../.id


mv ddcxui.ico    $ID.ico
mv ddcxui.lpi    $ID.lpi
mv ddcxui.lpr    $ID.lpr
mv ddcxui.lps    $ID.lps
mv ddcxui.res    $ID.res


gsed -Ei "s/ddcxui.lpr/$ID.lpr/g" $ID.lps
gsed -Ei "s/program ddcxui/program $ID/g" $ID.lpr
gsed -Ei "s/ddcxui.lpr/$ID.lpr/g" $ID.lpi
gsed -Ei "/Filename/s/ddcxui/$ID/g" $ID.lpi
