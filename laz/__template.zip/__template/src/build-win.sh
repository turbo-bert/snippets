#!/bin/bash

source .id

T=$(date +%s)
B=build/win-$T
mkdir -p $B

ssh lz "cd tmp & rmdir /S /Q src"

scp -r src lz:tmp

ssh lz "cd tmp\\src & c:\\Lazarus34\\lazbuild $ID.lpi"
EC=$?

scp -r lz:tmp/src/$ID.exe $B
echo $EC

scp $B/$ID.exe lz:Desktop


exit 0
