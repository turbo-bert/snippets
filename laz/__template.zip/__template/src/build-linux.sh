#!/bin/bash

source .id

T=$(date +%s)
B=build/linux-$T
mkdir -p $B
make clean
#( cd src && $L ddcxui.lpi )


H=homer
COMPILE_USER=bob

ssh $H "rm -fr /home/$COMPILE_USER/tmp; mkdir -p /home/$COMPILE_USER/tmp;"

rsync -avPz --delete src $H:/home/$COMPILE_USER/tmp

ssh $H "chown -R $COMPILE_USER:$COMPILE_USER /home/$COMPILE_USER/tmp"

ssh $H "sudo -u $COMPILE_USER /bin/bash -c 'cd \$HOME/tmp/src && lazbuild $ID.lpi'"

rsync -avPz $H:/home/$COMPILE_USER/tmp/src/$ID $B
