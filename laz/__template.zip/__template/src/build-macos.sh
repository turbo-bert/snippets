#!/bin/bash


source .id

T=$(date +%s)
L=$HOME/Applications/lazarus/lazbuild
B=build/macos-$T
mkdir -p $B
make clean
( cd src && $L $ID.lpi )

rm -f src/$ID.app/Contents/MacOS/$ID
cp -a src/$ID src/$ID.app/Contents/MacOS
mv src/$ID.app $B

make clean

echo -- "---------------"
echo $B
echo -- "---------------"

